# MITS Department Summary Analyzer (separate module)

This module set adds a separate Department Summary pipeline. It does not replace your existing student-comments analyzer.

## Files

- `pdfTypeDetector.js`: extracts PDF text and identifies report type.
- `departmentSummaryAnalyzer.js`: extracts metadata and table rows using text positions and analyzes metrics.
- `departmentReportGenerator.js`: creates a landscape A4 PDF with an MITS-style header, metadata table, grid table and signature lines.
- `analysisRouter.js`: routes department summaries to the new analyzer and other report types to your existing analyzer.

## Dependencies

Use versions compatible with your existing project:

```bash
npm install pdfkit pdfjs-dist
```

If `pdfjs-dist` is already installed, do not upgrade it automatically. If your project is ESM-only, adapt CommonJS `require` to your module system.

## Integration

1. Copy these files into your backend services folder.
2. In `analysisRouter.js`, change `require("./pdfAnalyzer")` to the actual path of your current comments analyzer.
3. Call `analyzeUploadedPdf(pdfBuffer)` from your current upload controller.
4. For Department Summary reports, pass `result.analysis` to `generateDepartmentSummaryPdf(result.analysis, outputPath, options)`.
5. Supply official MITS logo image paths via `options.leftLogo` and `options.rightLogo` to reproduce the header logos.
6. Verify every extracted record before allowing official export.

Example:

```js
const path = require("path");
const {
  analyzeUploadedPdf,
  generateDepartmentSummaryPdf,
} = require("./services/analysisRouter");

const result = await analyzeUploadedPdf(pdfBuffer, {
  expectedRecordCount: 31,
  thresholds: {
    lowFfi: 3.0,
    watchFfi: 3.5,
    lowResponsePercent: 65,
    strongFfi: 4.0,
    strongResponsePercent: 80,
  },
});

if (result.reportType === "department_summary") {
  console.log(result.analysis.validation);
  console.log(result.analysis.warnings);

  // Do not export an official report until extraction has been checked.
  await generateDepartmentSummaryPdf(
    result.analysis,
    path.join(process.cwd(), "department-summary-output.pdf"),
    {
      leftLogo: path.join(process.cwd(), "assets", "mits-logo.png"),
      rightLogo: path.join(process.cwd(), "assets", "mits-right-logo.png"),
      rowsPerPage: [9, 14, 8],
    }
  );
}
```

## Accuracy and limitations

This code uses position-based extraction and known column boundaries from the supplied landscape A4 sample. Different revisions of the form may need updated `DEFAULT_COLUMNS`.

A generated PDF can match the structure and approximate styling, but cannot be guaranteed 100% pixel-identical until tested with your actual logos, fonts, backend dependencies and browser/export workflow. The report generator uses Helvetica/Times built-in fonts; provide official fonts if exact typography is required.

The sample has 31 records and source metadata: department average response 81.89%, DFI 3.55, programme B.Tech., session First Faculty Feedback July-Dec 2026. Test extracted values against the original before publishing. Do not treat warnings or unverified extraction as official results.

The report generator intentionally does not invent commentary or causal claims. Attention/strength thresholds are configurable examples, not official MITS policy.
